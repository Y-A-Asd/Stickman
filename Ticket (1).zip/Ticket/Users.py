class Users:
    pass