balance = 1500000
# class Player:
#     pass
        