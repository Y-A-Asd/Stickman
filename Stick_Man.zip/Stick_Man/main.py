from Stick_Man.command.Get_Commands import get_commands

if __name__ == '__main__':
    get_commands()